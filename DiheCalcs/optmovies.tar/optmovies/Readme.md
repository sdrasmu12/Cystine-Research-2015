Contains the printed .xyz files from optimizations as part of energy calculations.
