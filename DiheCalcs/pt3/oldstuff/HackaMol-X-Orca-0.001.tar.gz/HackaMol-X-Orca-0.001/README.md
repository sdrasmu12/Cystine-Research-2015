# HackaMol-X-Orca

Very preliminary

It is turning out to be more convenient to have most methods return new molecules

