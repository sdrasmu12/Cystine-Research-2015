use Modern::Perl;
use HackaMol::X::Orca;
use Math::Vector::Real;
use HackaMol;
use Time::HiRes qw(time);
use Data::Dumper;

my $t1 = time;

my $mol = HackaMol->new->read_file_mol(shift);

$mol->charge(0);
$mol->multiplicity(1);

my $orca2 = HackaMol::X::Orca->new(
      mol    => $mol,
      theory => 'HF-3c',
      exe    => '/Users/riccade/perl5/apps/orca_3_0_3_macosx_openmpi165/orca',
      scratch => 'tmp',
);

$orca2->opt;
my $opt_mol = $orca2->load_trj;

$opt_mol->print_xyz_ts([0 .. $opt_mol->tmax]);

