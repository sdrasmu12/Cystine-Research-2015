use Modern::Perl;
use HackaMol::X::Orca;
use Math::Vector::Real;
use HackaMol;
use Time::HiRes qw(time);
use Data::Dumper;

my $orca = HackaMol::X::Orca->new(scratch => 'tmp');
my $mol2 = $orca->load_engrad;
say foreach $mol2->all_energy;
$mol2->print_xyz;

print Dumper $mol2;
